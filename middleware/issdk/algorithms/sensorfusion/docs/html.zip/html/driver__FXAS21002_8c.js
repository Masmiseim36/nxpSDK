var driver__FXAS21002_8c =
[
    [ "FXAS21000_COUNTSPERDEGPERSEC", "driver__FXAS21002_8c.html#ad729ac3263df225b8ebe64394c06ae5c", null ],
    [ "FXAS21000_CTRL_REG0", "driver__FXAS21002_8c.html#abee9f1d68dad80b6075c2fe493aa6c9e", null ],
    [ "FXAS21000_CTRL_REG1", "driver__FXAS21002_8c.html#ac6cb6a8c57c8b6b6e835dd5615dab36c", null ],
    [ "FXAS21000_CTRL_REG2", "driver__FXAS21002_8c.html#aa64e242b9f373eb454306cb7b1595eee", null ],
    [ "FXAS21000_F_SETUP", "driver__FXAS21002_8c.html#a100ef421feb1ba8269d586eb41ee464a", null ],
    [ "FXAS21000_F_STATUS", "driver__FXAS21002_8c.html#a882286434d0cffca50ee172a7514d04f", null ],
    [ "FXAS21000_STATUS", "driver__FXAS21002_8c.html#ab8b4c1cfaa54bce37dfd8d16fbad7d14", null ],
    [ "FXAS21000_WHO_AM_I", "driver__FXAS21002_8c.html#ac255d24201ab9874d876519d0c77b717", null ],
    [ "FXAS21000_WHO_AM_I_VALUE", "driver__FXAS21002_8c.html#ac021112534d845ac5dd9235c86bb929d", null ],
    [ "FXAS21002_COUNTSPERDEGPERSEC", "driver__FXAS21002_8c.html#ac4b942f72b2c1d1a0f16d832fcabd716", null ],
    [ "FXAS21002_GYRO_FIFO_SIZE", "driver__FXAS21002_8c.html#a3fe2519a64ebf20f9d3c4648a3bcfc8b", null ]
];