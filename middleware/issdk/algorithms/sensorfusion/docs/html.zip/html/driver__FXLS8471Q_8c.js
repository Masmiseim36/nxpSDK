var driver__FXLS8471Q_8c =
[
    [ "FXLS8471Q_ACCEL_FIFO_SIZE", "driver__FXLS8471Q_8c.html#acf497ea8a5db51068e208102a09f6edf", null ],
    [ "FXLS8471Q_COUNTSPERG", "driver__FXLS8471Q_8c.html#add3ef91902526b46454184e9caf17f81", null ],
    [ "FXLS8471Q_Idle", "driver__FXLS8471Q_8c.html#ae3e6043a3095f596460dd5d98dd1cd19", null ],
    [ "FXLS8471Q_Init", "driver__FXLS8471Q_8c.html#a562362f122065dbadacd859672964596", null ],
    [ "FXLS8471Q_Read", "driver__FXLS8471Q_8c.html#a33189bcbbd5761f2b9b5032fd499e0ea", null ],
    [ "FXLS8471Q_DATA_READ", "driver__FXLS8471Q_8c.html#af83de7980f4bc0288f56e874bf750bfd", null ],
    [ "FXLS8471Q_F_STATUS_READ", "driver__FXLS8471Q_8c.html#abed08ce6b0ec2cd90648fb8c0e673a6d", null ],
    [ "FXLS8471Q_IDLE", "driver__FXLS8471Q_8c.html#a2fc1b2292b8a7e6c313a16f25937eea7", null ],
    [ "FXLS8471Q_Initialization", "driver__FXLS8471Q_8c.html#a5ee03e031e9da54109eb632c4982a9ee", null ],
    [ "FXLS8471Q_WHO_AM_I_READ", "driver__FXLS8471Q_8c.html#a104d1bcc8561c435d87dee7a45246221", null ]
];