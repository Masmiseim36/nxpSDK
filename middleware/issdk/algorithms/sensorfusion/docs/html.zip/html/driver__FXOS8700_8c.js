var driver__FXOS8700_8c =
[
    [ "FXOS8700_ACCEL_FIFO_SIZE", "driver__FXOS8700_8c.html#ac44229faa277b615baafae32d3339aa0", null ],
    [ "FXOS8700_COUNTSPERG", "driver__FXOS8700_8c.html#aba2d125a7c20d788b7f6931afdab3e80", null ],
    [ "FXOS8700_COUNTSPERUT", "driver__FXOS8700_8c.html#aafab1912835ff90c989e1c35ddc8bb77", null ],
    [ "FXOS8700_MAG_FIFO_SIZE", "driver__FXOS8700_8c.html#a4ba9c72da36f6d2e9f3380868751a867", null ],
    [ "FXOS8700_Idle", "driver__FXOS8700_8c.html#a81eb6639a3336411c9c255f1db98ea7f", null ],
    [ "FXOS8700_Init", "driver__FXOS8700_8c.html#a905984cc5f2e42228183217f6d071fb8", null ],
    [ "FXOS8700_Read", "driver__FXOS8700_8c.html#a15f78e72d6a7dec25d95d97fa4c8d00e", null ],
    [ "FXOS8700_ReadMagData", "driver__FXOS8700_8c.html#a426c0f9617cbeffebfeaadd6446c3bc2", null ],
    [ "FXOS8700_DATA_READ", "driver__FXOS8700_8c.html#a75f990778a08ee286d0761e17a884fee", null ],
    [ "FXOS8700_F_STATUS_READ", "driver__FXOS8700_8c.html#a96261904d66b2f6f7ae43d37d0bd032a", null ],
    [ "FXOS8700_FULL_IDLE", "driver__FXOS8700_8c.html#ab35eff335189522162903b9d1d084b13", null ],
    [ "FXOS8700_Initialization", "driver__FXOS8700_8c.html#a59fd78ede6955ecb2f9e32387342bedd", null ],
    [ "FXOS8700_WHO_AM_I_READ", "driver__FXOS8700_8c.html#a248e5aefab5218c66ac5f0d93268589d", null ]
];