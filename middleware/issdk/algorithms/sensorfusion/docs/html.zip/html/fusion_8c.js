var fusion_8c =
[
    [ "fFuseSensors", "fusion_8c.html#aeb60375528d75ee9fec67a96916141ca", null ],
    [ "fInit_1DOF_P_BASIC", "fusion_8c.html#aa42722127b9e91519749cba1cfa07ebe", null ],
    [ "fInit_3DOF_B_BASIC", "fusion_8c.html#adc49d74394c2a94a33ff65edea18233b", null ],
    [ "fInit_3DOF_G_BASIC", "fusion_8c.html#a41f2c6419c8e0c019e08618283338d21", null ],
    [ "fInit_3DOF_Y_BASIC", "fusion_8c.html#a0d585ddb24fa91e8d18228bee7a9539c", null ],
    [ "fInit_6DOF_GB_BASIC", "fusion_8c.html#ab5f459ab0c8c9b4123e2fb33f5061332", null ],
    [ "fInit_6DOF_GY_KALMAN", "fusion_8c.html#adb837744c0801f50a0890f1385ca5c75", null ],
    [ "fInit_9DOF_GBY_KALMAN", "fusion_8c.html#a5627f82d4cbb9af1102d10ad1bea3699", null ],
    [ "fInitializeFusion", "fusion_8c.html#ad9cb3659204ae7a30109ceaf4d94ecec", null ],
    [ "fRun_1DOF_P_BASIC", "fusion_8c.html#a2e2258d4d0cd14011d5b198b8cbdab95", null ],
    [ "fRun_3DOF_B_BASIC", "fusion_8c.html#a2df5be5795338038774a64b41cf53a8e", null ],
    [ "fRun_3DOF_G_BASIC", "fusion_8c.html#a7b5db1923cfa0dc160016e7d9b45b1c2", null ],
    [ "fRun_3DOF_Y_BASIC", "fusion_8c.html#a288f51cd39aeb8ace643d844e219e9d3", null ],
    [ "fRun_6DOF_GB_BASIC", "fusion_8c.html#a34c550860d0e4e42bf22a2a3527043b9", null ],
    [ "fRun_6DOF_GY_KALMAN", "fusion_8c.html#a942d619f897d6820d5c148bdc910f962", null ]
];