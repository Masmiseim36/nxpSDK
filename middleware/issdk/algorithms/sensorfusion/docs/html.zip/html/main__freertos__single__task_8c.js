var main__freertos__single__task_8c =
[
    [ "I2C_DRIVER", "main__freertos__single__task_8c.html#aa7c92eb0b1fc8fa40117dcbdd8213960", null ],
    [ "main", "main__freertos__single__task_8c.html#a840291bc02cba5474a4cb46a9b9566fe", null ],
    [ "myI2C_callback", "main__freertos__single__task_8c.html#a74c29746b187d40824203a7cbfa27b6e", null ],
    [ "read_task", "main__freertos__single__task_8c.html#ad4761540f9eeaae0661637c047c892b0", null ],
    [ "controlSubsystem", "main__freertos__single__task_8c.html#a641b380af068b4004bc5b9dff5e5a6db", null ],
    [ "Driver_I2C1_KSDK2_Blocking", "main__freertos__single__task_8c.html#a72cd3bc11b88f8a5a11a5a0bbc6999af", null ],
    [ "event_group", "main__freertos__single__task_8c.html#a729bc9c4006e68fecea92342c3c3700b", null ],
    [ "I2Cdrv", "main__freertos__single__task_8c.html#a3c22bed16a7c769894081222aa6107d8", null ],
    [ "sensors", "main__freertos__single__task_8c.html#aae480723980bda2d3ded777ff310d6d9", null ],
    [ "sfg", "main__freertos__single__task_8c.html#afa81c629d378fe700f351a1bce411ad5", null ],
    [ "statusSubsystem", "main__freertos__single__task_8c.html#a875f795e25aaef1b828061bbfae4764a", null ],
    [ "sUARTOutputBuffer", "main__freertos__single__task_8c.html#a3b6c71dda245dccb73352c7264176527", null ]
];