var precisionAccelerometer_8h =
[
    [ "AccelBuffer", "structAccelBuffer.html", "structAccelBuffer" ],
    [ "AccelCalibration", "structAccelCalibration.html", "structAccelCalibration" ],
    [ "ACCEL_CAL_AVERAGING_SECS", "precisionAccelerometer_8h.html#a2b9b9bab44fce8ba83b6da0bc9edb21c", null ],
    [ "MAX_ACCEL_CAL_ORIENTATIONS", "precisionAccelerometer_8h.html#a5ed11d7ac5361003e06a95d4f7a3fcb7", null ],
    [ "AccelBuffer", "precisionAccelerometer_8h.html#aefb73fe7a6084794e760cfb462b0af4e", null ],
    [ "AccelCalibration", "precisionAccelerometer_8h.html#a84e482137194b03bd6686fb8b49ab6fc", null ],
    [ "fComputeAccelCalibration10", "precisionAccelerometer_8h.html#a752887e826809837549c391aa3a4cbaf", null ],
    [ "fComputeAccelCalibration4", "precisionAccelerometer_8h.html#a32c25ed3da9ec249bba57bbb1ab2d091", null ],
    [ "fComputeAccelCalibration7", "precisionAccelerometer_8h.html#a2f17e091698125acbf0cdb780c2c93da", null ],
    [ "fInitializeAccelCalibration", "precisionAccelerometer_8h.html#a051f7646b706301ee61a2ba8b331ec4d", null ],
    [ "fInvertAccelCal", "precisionAccelerometer_8h.html#a3aa550d5d9b592df3fd8b10c97c07d98", null ],
    [ "fRunAccelCalibration", "precisionAccelerometer_8h.html#a2670a39e8be35e9bad5a75d0ec8ca821", null ],
    [ "fUpdateAccelBuffer", "precisionAccelerometer_8h.html#a29cd1109b0584bd00d43c219f411437f", null ]
];