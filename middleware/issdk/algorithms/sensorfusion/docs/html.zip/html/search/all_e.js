var searchData=
[
  ['q0',['q0',['../structQuaternion.html#a27b8f713c4a449fb2fbb1cbdb3a1e149',1,'Quaternion']]],
  ['q1',['q1',['../structQuaternion.html#a209c65446ca302d32cbb908c4d75f616',1,'Quaternion']]],
  ['q2',['q2',['../structQuaternion.html#afddca3451c589f7b5928b6dccf8c88ba',1,'Quaternion']]],
  ['q3',['q3',['../structQuaternion.html#aa92940755b1370321ed489e6f2448ad9',1,'Quaternion::q3()'],['../sensor__fusion_8h.html#a5f469312b3865f2d3efea2edd6f8afaaa19bd87b11e82b9047ad750fb62711ba8',1,'Q3():&#160;sensor_fusion.h']]],
  ['q3g',['Q3G',['../sensor__fusion_8h.html#a5f469312b3865f2d3efea2edd6f8afaaaf63c9f6fec59717499a84048f682cf8a',1,'sensor_fusion.h']]],
  ['q3m',['Q3M',['../sensor__fusion_8h.html#a5f469312b3865f2d3efea2edd6f8afaaada2dae63d5865a8446caa7938c73c5dc',1,'sensor_fusion.h']]],
  ['q6ag',['Q6AG',['../sensor__fusion_8h.html#a5f469312b3865f2d3efea2edd6f8afaaa59c8dc55b720396019ef93eb943a3b96',1,'sensor_fusion.h']]],
  ['q6ma',['Q6MA',['../sensor__fusion_8h.html#a5f469312b3865f2d3efea2edd6f8afaaa0cf62dda224dcbac09ae26cd46ccce01',1,'sensor_fusion.h']]],
  ['q9',['Q9',['../sensor__fusion_8h.html#a5f469312b3865f2d3efea2edd6f8afaaa9c5ceeb2bc9bf27379c7e72bc4d0ff13',1,'sensor_fusion.h']]],
  ['qaeqaxb',['qAeqAxB',['../orientation_8c.html#a22a32becfcb162db012f41ff4f3bc942',1,'qAeqAxB(Quaternion *pqA, const Quaternion *pqB):&#160;orientation.c'],['../orientation_8h.html#a22a32becfcb162db012f41ff4f3bc942',1,'qAeqAxB(Quaternion *pqA, const Quaternion *pqB):&#160;orientation.c']]],
  ['qaeqbxc',['qAeqBxC',['../orientation_8c.html#a12448c36b93d8f3375ce000ef4527b4a',1,'qAeqBxC(Quaternion *pqA, const Quaternion *pqB, const Quaternion *pqC):&#160;orientation.c'],['../orientation_8h.html#a12448c36b93d8f3375ce000ef4527b4a',1,'qAeqBxC(Quaternion *pqA, const Quaternion *pqB, const Quaternion *pqC):&#160;orientation.c']]],
  ['qconjgaxb',['qconjgAxB',['../orientation_8c.html#adb2ea2734ac13ca77b3218d761fe45e0',1,'qconjgAxB(const Quaternion *pqA, const Quaternion *pqB):&#160;orientation.c'],['../orientation_8h.html#adb2ea2734ac13ca77b3218d761fe45e0',1,'qconjgAxB(const Quaternion *pqA, const Quaternion *pqB):&#160;orientation.c']]],
  ['quaternion',['Quaternion',['../structQuaternion.html',1,'Quaternion'],['../sensor__fusion_8h.html#a5f469312b3865f2d3efea2edd6f8afaa',1,'quaternion():&#160;sensor_fusion.h'],['../orientation_8h.html#a5cd3d2a1a3d256bebeec4da81b7f4d94',1,'Quaternion():&#160;orientation.h']]],
  ['quaternion_5ftype',['quaternion_type',['../sensor__fusion_8h.html#ad1d4d649bfa88f655f8f2d1ee5ae5ace',1,'sensor_fusion.h']]],
  ['quaternionpackettype',['QuaternionPacketType',['../structControlSubsystem.html#a560615429c69fcefa85de0624fa6d83e',1,'ControlSubsystem']]],
  ['queue',['queue',['../structStatusSubsystem.html#a15f064f701fa865d5ef96db12a023ef0',1,'StatusSubsystem']]],
  ['queuestatus',['queueStatus',['../structSensorFusionGlobals.html#af6a232c7866a9093f9a5cb51372d4f97',1,'SensorFusionGlobals::queueStatus()'],['../sensor__fusion_8c.html#ae96e36747e6a1aabbec1381f15132ec6',1,'queueStatus():&#160;sensor_fusion.c']]]
];
