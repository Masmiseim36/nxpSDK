var searchData=
[
  ['defaultb',['DEFAULTB',['../magnetic_8h.html#a7fbd52f6b6770a07809e1715efa54adb',1,'magnetic.h']]]
];
