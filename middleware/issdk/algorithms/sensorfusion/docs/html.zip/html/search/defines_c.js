var searchData=
[
  ['r',['R',['../status_8c.html#a5c71a5e59a53413cd6c270266d63b031',1,'status.c']]],
  ['rateresolution',['RATERESOLUTION',['../output__stream_8c.html#a9badfcf686c8cfb2afabc3c9e3ba11d3',1,'output_stream.c']]],
  ['reserved0',['RESERVED0',['../board__encodings_8h.html#a33aef9a07b67896698c78308a04e22f5',1,'board_encodings.h']]]
];
