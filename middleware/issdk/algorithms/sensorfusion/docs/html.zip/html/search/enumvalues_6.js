var searchData=
[
  ['receiving_5fwired',['RECEIVING_WIRED',['../sensor__fusion_8h.html#a69ee883e1c22b117df163c0bd83f66dda07ce7fbb8426233b33e7e7512bb0f55d',1,'sensor_fusion.h']]],
  ['receiving_5fwireless',['RECEIVING_WIRELESS',['../sensor__fusion_8h.html#a69ee883e1c22b117df163c0bd83f66dda60ca895e5ed18a6e1928d4750c7968a0',1,'sensor_fusion.h']]]
];
