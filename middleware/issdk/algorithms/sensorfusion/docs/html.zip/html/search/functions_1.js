var searchData=
[
  ['blueradios_5finit',['BlueRadios_Init',['../control_8c.html#a0022c0c45a3b736ffe21164001662b44',1,'BlueRadios_Init(void):&#160;control.c'],['../control_8h.html#a0022c0c45a3b736ffe21164001662b44',1,'BlueRadios_Init(void):&#160;control.c']]]
];
