var searchData=
[
  ['decodecommandbytes',['DecodeCommandBytes',['../control_8h.html#a2d80b68d03de87c2d3cce67273f8a165',1,'DecodeCommandBytes(SensorFusionGlobals *sfg, char iCommandBuffer[], uint8 sUART_InputBuffer[], uint16 nbytes):&#160;DecodeCommandBytes.c'],['../DecodeCommandBytes_8c.html#a2d80b68d03de87c2d3cce67273f8a165',1,'DecodeCommandBytes(SensorFusionGlobals *sfg, char iCommandBuffer[], uint8 sUART_InputBuffer[], uint16 nbytes):&#160;DecodeCommandBytes.c']]]
];
