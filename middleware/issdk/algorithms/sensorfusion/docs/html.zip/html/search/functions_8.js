var searchData=
[
  ['nvm_5fsetblockflash',['NVM_SetBlockFlash',['../driver__KSDK__NVM_8c.html#ac226b4393abef43297aa13addf70f2f1',1,'NVM_SetBlockFlash(uint8_t *Source, uint32_t Dest, uint16_t Count):&#160;driver_KSDK_NVM.c'],['../driver__KSDK__NVM_8h.html#ac226b4393abef43297aa13addf70f2f1',1,'NVM_SetBlockFlash(uint8_t *Source, uint32_t Dest, uint16_t Count):&#160;driver_KSDK_NVM.c']]]
];
