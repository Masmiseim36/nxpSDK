var searchData=
[
  ['pit_5finit',['pit_init',['../driver__pit_8c.html#aa9242caadd99e8ac4fdce86681b61740',1,'pit_init(uint32_t microseconds):&#160;driver_pit.c'],['../driver__pit_8h.html#aa9242caadd99e8ac4fdce86681b61740',1,'pit_init(uint32_t microseconds):&#160;driver_pit.c']]],
  ['pit_5fled_5fhandler',['PIT_LED_HANDLER',['../driver__pit_8c.html#a06fa5975f12d96fe146671dfd5af4b2f',1,'driver_pit.c']]],
  ['processmagdata',['processMagData',['../sensor__fusion_8c.html#aaf8b47198fa614f0b50265addf44a8b0',1,'sensor_fusion.c']]]
];
