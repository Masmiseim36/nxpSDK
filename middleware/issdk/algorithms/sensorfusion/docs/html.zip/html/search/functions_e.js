var searchData=
[
  ['updatestatus',['updateStatus',['../sensor__fusion_8c.html#aa13c4a9f07f3a2abfdb2e0808e5752d4',1,'sensor_fusion.c']]]
];
