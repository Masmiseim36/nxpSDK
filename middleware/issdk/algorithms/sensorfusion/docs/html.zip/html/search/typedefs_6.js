var searchData=
[
  ['magbuffer',['MagBuffer',['../magnetic_8h.html#a649f7679493d773ce9a01c4e5597b485',1,'magnetic.h']]],
  ['magcalibration',['MagCalibration',['../magnetic_8h.html#a5d846426da2afe9bc24062efc8988885',1,'magnetic.h']]],
  ['magsensor',['MagSensor',['../sensor__fusion_8h.html#a8e67c06bd3b19216590e009ca573467e',1,'sensor_fusion.h']]]
];
