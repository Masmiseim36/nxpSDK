var searchData=
[
  ['quaternion',['Quaternion',['../orientation_8h.html#a5cd3d2a1a3d256bebeec4da81b7f4d94',1,'orientation.h']]],
  ['quaternion_5ftype',['quaternion_type',['../sensor__fusion_8h.html#ad1d4d649bfa88f655f8f2d1ee5ae5ace',1,'sensor_fusion.h']]]
];
