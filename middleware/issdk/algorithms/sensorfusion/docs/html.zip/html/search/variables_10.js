var searchData=
[
  ['update',['update',['../structStatusSubsystem.html#a928558f2d3d07e91b583fa7e67368b59',1,'StatusSubsystem']]],
  ['updatestatus',['updateStatus',['../structSensorFusionGlobals.html#a186a484bdd7f6c3210a2ee6d2763c6a2',1,'SensorFusionGlobals']]]
];
